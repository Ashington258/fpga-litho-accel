// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XCALC_SOCS_SIMPLE_HLS_H
#define XCALC_SOCS_SIMPLE_HLS_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xcalc_socs_simple_hls_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
} XCalc_socs_simple_hls_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
    u32 IsReady;
} XCalc_socs_simple_hls;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XCalc_socs_simple_hls_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XCalc_socs_simple_hls_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XCalc_socs_simple_hls_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XCalc_socs_simple_hls_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XCalc_socs_simple_hls_Initialize(XCalc_socs_simple_hls *InstancePtr, UINTPTR BaseAddress);
XCalc_socs_simple_hls_Config* XCalc_socs_simple_hls_LookupConfig(UINTPTR BaseAddress);
#else
int XCalc_socs_simple_hls_Initialize(XCalc_socs_simple_hls *InstancePtr, u16 DeviceId);
XCalc_socs_simple_hls_Config* XCalc_socs_simple_hls_LookupConfig(u16 DeviceId);
#endif
int XCalc_socs_simple_hls_CfgInitialize(XCalc_socs_simple_hls *InstancePtr, XCalc_socs_simple_hls_Config *ConfigPtr);
#else
int XCalc_socs_simple_hls_Initialize(XCalc_socs_simple_hls *InstancePtr, const char* InstanceName);
int XCalc_socs_simple_hls_Release(XCalc_socs_simple_hls *InstancePtr);
#endif

void XCalc_socs_simple_hls_Start(XCalc_socs_simple_hls *InstancePtr);
u32 XCalc_socs_simple_hls_IsDone(XCalc_socs_simple_hls *InstancePtr);
u32 XCalc_socs_simple_hls_IsIdle(XCalc_socs_simple_hls *InstancePtr);
u32 XCalc_socs_simple_hls_IsReady(XCalc_socs_simple_hls *InstancePtr);
void XCalc_socs_simple_hls_EnableAutoRestart(XCalc_socs_simple_hls *InstancePtr);
void XCalc_socs_simple_hls_DisableAutoRestart(XCalc_socs_simple_hls *InstancePtr);

void XCalc_socs_simple_hls_Set_mskf_r(XCalc_socs_simple_hls *InstancePtr, u64 Data);
u64 XCalc_socs_simple_hls_Get_mskf_r(XCalc_socs_simple_hls *InstancePtr);
void XCalc_socs_simple_hls_Set_mskf_i(XCalc_socs_simple_hls *InstancePtr, u64 Data);
u64 XCalc_socs_simple_hls_Get_mskf_i(XCalc_socs_simple_hls *InstancePtr);
void XCalc_socs_simple_hls_Set_scales(XCalc_socs_simple_hls *InstancePtr, u64 Data);
u64 XCalc_socs_simple_hls_Get_scales(XCalc_socs_simple_hls *InstancePtr);
void XCalc_socs_simple_hls_Set_krn_r(XCalc_socs_simple_hls *InstancePtr, u64 Data);
u64 XCalc_socs_simple_hls_Get_krn_r(XCalc_socs_simple_hls *InstancePtr);
void XCalc_socs_simple_hls_Set_krn_i(XCalc_socs_simple_hls *InstancePtr, u64 Data);
u64 XCalc_socs_simple_hls_Get_krn_i(XCalc_socs_simple_hls *InstancePtr);
void XCalc_socs_simple_hls_Set_output_full(XCalc_socs_simple_hls *InstancePtr, u64 Data);
u64 XCalc_socs_simple_hls_Get_output_full(XCalc_socs_simple_hls *InstancePtr);
void XCalc_socs_simple_hls_Set_output_center(XCalc_socs_simple_hls *InstancePtr, u64 Data);
u64 XCalc_socs_simple_hls_Get_output_center(XCalc_socs_simple_hls *InstancePtr);

void XCalc_socs_simple_hls_InterruptGlobalEnable(XCalc_socs_simple_hls *InstancePtr);
void XCalc_socs_simple_hls_InterruptGlobalDisable(XCalc_socs_simple_hls *InstancePtr);
void XCalc_socs_simple_hls_InterruptEnable(XCalc_socs_simple_hls *InstancePtr, u32 Mask);
void XCalc_socs_simple_hls_InterruptDisable(XCalc_socs_simple_hls *InstancePtr, u32 Mask);
void XCalc_socs_simple_hls_InterruptClear(XCalc_socs_simple_hls *InstancePtr, u32 Mask);
u32 XCalc_socs_simple_hls_InterruptGetEnabled(XCalc_socs_simple_hls *InstancePtr);
u32 XCalc_socs_simple_hls_InterruptGetStatus(XCalc_socs_simple_hls *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
