// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xcalc_socs_simple_hls.h"

extern XCalc_socs_simple_hls_Config XCalc_socs_simple_hls_ConfigTable[];

#ifdef SDT
XCalc_socs_simple_hls_Config *XCalc_socs_simple_hls_LookupConfig(UINTPTR BaseAddress) {
	XCalc_socs_simple_hls_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XCalc_socs_simple_hls_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XCalc_socs_simple_hls_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XCalc_socs_simple_hls_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XCalc_socs_simple_hls_Initialize(XCalc_socs_simple_hls *InstancePtr, UINTPTR BaseAddress) {
	XCalc_socs_simple_hls_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XCalc_socs_simple_hls_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XCalc_socs_simple_hls_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XCalc_socs_simple_hls_Config *XCalc_socs_simple_hls_LookupConfig(u16 DeviceId) {
	XCalc_socs_simple_hls_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XCALC_SOCS_SIMPLE_HLS_NUM_INSTANCES; Index++) {
		if (XCalc_socs_simple_hls_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XCalc_socs_simple_hls_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XCalc_socs_simple_hls_Initialize(XCalc_socs_simple_hls *InstancePtr, u16 DeviceId) {
	XCalc_socs_simple_hls_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XCalc_socs_simple_hls_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XCalc_socs_simple_hls_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

