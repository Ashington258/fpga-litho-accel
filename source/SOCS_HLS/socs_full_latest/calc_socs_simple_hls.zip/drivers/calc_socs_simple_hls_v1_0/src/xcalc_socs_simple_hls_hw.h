// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x0 : Control signals
//       bit 0  - ap_start (Read/Write/COH)
//       bit 1  - ap_done (Read/COR)
//       bit 2  - ap_idle (Read)
//       bit 3  - ap_ready (Read/COR)
//       bit 7  - auto_restart (Read/Write)
//       bit 9  - interrupt (Read)
//       others - reserved
// 0x4 : Global Interrupt Enable Register
//       bit 0  - Global Interrupt Enable (Read/Write)
//       others - reserved
// 0x8 : IP Interrupt Enable Register (Read/Write)
//       bit 0 - enable ap_done interrupt (Read/Write)
//       bit 1 - enable ap_ready interrupt (Read/Write)
//       others - reserved
// 0xc : IP Interrupt Status Register (Read/TOW)
//       bit 0 - ap_done (Read/TOW)
//       bit 1 - ap_ready (Read/TOW)
//       others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_AP_CTRL 0x0
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_GIE     0x4
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_IER     0x8
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_ISR     0xc

// control_r
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of mskf_r
//        bit 31~0 - mskf_r[31:0] (Read/Write)
// 0x14 : Data signal of mskf_r
//        bit 31~0 - mskf_r[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of mskf_i
//        bit 31~0 - mskf_i[31:0] (Read/Write)
// 0x20 : Data signal of mskf_i
//        bit 31~0 - mskf_i[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of scales
//        bit 31~0 - scales[31:0] (Read/Write)
// 0x2c : Data signal of scales
//        bit 31~0 - scales[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of krn_r
//        bit 31~0 - krn_r[31:0] (Read/Write)
// 0x38 : Data signal of krn_r
//        bit 31~0 - krn_r[63:32] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of krn_i
//        bit 31~0 - krn_i[31:0] (Read/Write)
// 0x44 : Data signal of krn_i
//        bit 31~0 - krn_i[63:32] (Read/Write)
// 0x48 : reserved
// 0x4c : Data signal of output_full
//        bit 31~0 - output_full[31:0] (Read/Write)
// 0x50 : Data signal of output_full
//        bit 31~0 - output_full[63:32] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of output_center
//        bit 31~0 - output_center[31:0] (Read/Write)
// 0x5c : Data signal of output_center
//        bit 31~0 - output_center[63:32] (Read/Write)
// 0x60 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_MSKF_R_DATA        0x10
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_R_BITS_MSKF_R_DATA        64
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_MSKF_I_DATA        0x1c
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_R_BITS_MSKF_I_DATA        64
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_SCALES_DATA        0x28
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_R_BITS_SCALES_DATA        64
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_KRN_R_DATA         0x34
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_R_BITS_KRN_R_DATA         64
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_KRN_I_DATA         0x40
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_R_BITS_KRN_I_DATA         64
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_OUTPUT_FULL_DATA   0x4c
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_R_BITS_OUTPUT_FULL_DATA   64
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_OUTPUT_CENTER_DATA 0x58
#define XCALC_SOCS_SIMPLE_HLS_CONTROL_R_BITS_OUTPUT_CENTER_DATA 64

