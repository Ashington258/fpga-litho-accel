// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xcalc_socs_simple_hls.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XCalc_socs_simple_hls_CfgInitialize(XCalc_socs_simple_hls *InstancePtr, XCalc_socs_simple_hls_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XCalc_socs_simple_hls_Start(XCalc_socs_simple_hls *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_AP_CTRL) & 0x80;
    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XCalc_socs_simple_hls_IsDone(XCalc_socs_simple_hls *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XCalc_socs_simple_hls_IsIdle(XCalc_socs_simple_hls *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XCalc_socs_simple_hls_IsReady(XCalc_socs_simple_hls *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XCalc_socs_simple_hls_EnableAutoRestart(XCalc_socs_simple_hls *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XCalc_socs_simple_hls_DisableAutoRestart(XCalc_socs_simple_hls *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_AP_CTRL, 0);
}

void XCalc_socs_simple_hls_Set_mskf_r(XCalc_socs_simple_hls *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_MSKF_R_DATA, (u32)(Data));
    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_MSKF_R_DATA + 4, (u32)(Data >> 32));
}

u64 XCalc_socs_simple_hls_Get_mskf_r(XCalc_socs_simple_hls *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_MSKF_R_DATA);
    Data += (u64)XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_MSKF_R_DATA + 4) << 32;
    return Data;
}

void XCalc_socs_simple_hls_Set_mskf_i(XCalc_socs_simple_hls *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_MSKF_I_DATA, (u32)(Data));
    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_MSKF_I_DATA + 4, (u32)(Data >> 32));
}

u64 XCalc_socs_simple_hls_Get_mskf_i(XCalc_socs_simple_hls *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_MSKF_I_DATA);
    Data += (u64)XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_MSKF_I_DATA + 4) << 32;
    return Data;
}

void XCalc_socs_simple_hls_Set_scales(XCalc_socs_simple_hls *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_SCALES_DATA, (u32)(Data));
    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_SCALES_DATA + 4, (u32)(Data >> 32));
}

u64 XCalc_socs_simple_hls_Get_scales(XCalc_socs_simple_hls *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_SCALES_DATA);
    Data += (u64)XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_SCALES_DATA + 4) << 32;
    return Data;
}

void XCalc_socs_simple_hls_Set_krn_r(XCalc_socs_simple_hls *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_KRN_R_DATA, (u32)(Data));
    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_KRN_R_DATA + 4, (u32)(Data >> 32));
}

u64 XCalc_socs_simple_hls_Get_krn_r(XCalc_socs_simple_hls *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_KRN_R_DATA);
    Data += (u64)XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_KRN_R_DATA + 4) << 32;
    return Data;
}

void XCalc_socs_simple_hls_Set_krn_i(XCalc_socs_simple_hls *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_KRN_I_DATA, (u32)(Data));
    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_KRN_I_DATA + 4, (u32)(Data >> 32));
}

u64 XCalc_socs_simple_hls_Get_krn_i(XCalc_socs_simple_hls *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_KRN_I_DATA);
    Data += (u64)XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_KRN_I_DATA + 4) << 32;
    return Data;
}

void XCalc_socs_simple_hls_Set_output_full(XCalc_socs_simple_hls *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_OUTPUT_FULL_DATA, (u32)(Data));
    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_OUTPUT_FULL_DATA + 4, (u32)(Data >> 32));
}

u64 XCalc_socs_simple_hls_Get_output_full(XCalc_socs_simple_hls *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_OUTPUT_FULL_DATA);
    Data += (u64)XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_OUTPUT_FULL_DATA + 4) << 32;
    return Data;
}

void XCalc_socs_simple_hls_Set_output_center(XCalc_socs_simple_hls *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_OUTPUT_CENTER_DATA, (u32)(Data));
    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_OUTPUT_CENTER_DATA + 4, (u32)(Data >> 32));
}

u64 XCalc_socs_simple_hls_Get_output_center(XCalc_socs_simple_hls *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_OUTPUT_CENTER_DATA);
    Data += (u64)XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_r_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_R_ADDR_OUTPUT_CENTER_DATA + 4) << 32;
    return Data;
}

void XCalc_socs_simple_hls_InterruptGlobalEnable(XCalc_socs_simple_hls *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_GIE, 1);
}

void XCalc_socs_simple_hls_InterruptGlobalDisable(XCalc_socs_simple_hls *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_GIE, 0);
}

void XCalc_socs_simple_hls_InterruptEnable(XCalc_socs_simple_hls *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_IER);
    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_IER, Register | Mask);
}

void XCalc_socs_simple_hls_InterruptDisable(XCalc_socs_simple_hls *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_IER);
    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_IER, Register & (~Mask));
}

void XCalc_socs_simple_hls_InterruptClear(XCalc_socs_simple_hls *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCalc_socs_simple_hls_WriteReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_ISR, Mask);
}

u32 XCalc_socs_simple_hls_InterruptGetEnabled(XCalc_socs_simple_hls *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_IER);
}

u32 XCalc_socs_simple_hls_InterruptGetStatus(XCalc_socs_simple_hls *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCalc_socs_simple_hls_ReadReg(InstancePtr->Control_BaseAddress, XCALC_SOCS_SIMPLE_HLS_CONTROL_ADDR_ISR);
}

